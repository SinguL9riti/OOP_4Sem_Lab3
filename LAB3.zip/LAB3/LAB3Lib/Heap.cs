﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace LAB3Lib
{
    // Класс кучи, реализующий интерфейс ICollection
    public class Heap<T> : ICollection<T> where T : IComparable<T>
    {
        private List<T> items = new List<T>(); // Список элементов кучи

        // Количество элементов в куче
        public int Count => items.Count;

        // Возможность только для чтения
        public bool IsReadOnly => false;

        // Добавление элемента в кучу
        public void Add(T item)
        {
            items.Add(item);
            HeapifyUp(items.Count - 1);
        }

        // Удаление корня кучи
        public T RemoveRoot()
        {
            if (items.Count == 0)
                throw new InvalidOperationException("Куча пуста");

            T root = items[0];
            items[0] = items[items.Count - 1];
            items.RemoveAt(items.Count - 1);
            HeapifyDown(0);
            return root;
        }

        // Приведение элемента к вершине кучи
        private void HeapifyUp(int index)
        {
            int parentIndex = (index - 1) / 2;
            while (index > 0 && items[index].CompareTo(items[parentIndex]) < 0)
            {
                Swap(index, parentIndex);
                index = parentIndex;
                parentIndex = (index - 1) / 2;
            }
        }

        // Приведение элемента к листу кучи
        private void HeapifyDown(int index)
        {
            int leftChildIndex, rightChildIndex, smallestChildIndex;

            while (true)
            {
                leftChildIndex = 2 * index + 1;
                rightChildIndex = 2 * index + 2;
                smallestChildIndex = index;

                if (leftChildIndex < items.Count && items[leftChildIndex].CompareTo(items[smallestChildIndex]) < 0)
                    smallestChildIndex = leftChildIndex;

                if (rightChildIndex < items.Count && items[rightChildIndex].CompareTo(items[smallestChildIndex]) < 0)
                    smallestChildIndex = rightChildIndex;

                if (smallestChildIndex == index)
                    break;

                Swap(index, smallestChildIndex);
                index = smallestChildIndex;
            }
        }

        // Обмен двух элементов в куче
        private void Swap(int index1, int index2)
        {
            T temp = items[index1];
            items[index1] = items[index2];
            items[index2] = temp;
        }

        // Возвращение перечислителя элементов кучи
        public IEnumerator<T> GetEnumerator()
        {
            return items.GetEnumerator();
        }

        // Возвращение перечислителя элементов кучи
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        // Очистка кучи
        public void Clear()
        {
            items.Clear();
        }

        // Проверка наличия элемента в куче
        public bool Contains(T item)
        {
            return items.Contains(item);
        }

        // Копирование элементов кучи в массив
        public void CopyTo(T[] array, int arrayIndex)
        {
            items.CopyTo(array, arrayIndex);
        }

        // Удаление элемента из кучи
        public bool Remove(T item)
        {
            throw new NotImplementedException();
        }
    }
}
