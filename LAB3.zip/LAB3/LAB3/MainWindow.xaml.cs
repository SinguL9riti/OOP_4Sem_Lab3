﻿using LAB3Lib;
using System;
using System.Windows;

namespace LAB3
{
    public partial class MainWindow : Window
    {
        private readonly Heap<int> heap = new Heap<int>(); // Создание экземпляра кучи для целых чисел
        private readonly Random random = new Random(); // Создание генератора случайных чисел

        public MainWindow()
        {
            InitializeComponent();
        }

        // Обновление ListBox, отображающего содержимое кучи
        private void UpdateHeapListBox()
        {
            heapListBox.Items.Clear();
            foreach (var item in heap)
            {
                heapListBox.Items.Add(item);
            }
        }

        // Обработчик нажатия на кнопку "Добавить случайный элемент"
        private void AddRandomItem_Click(object sender, RoutedEventArgs e)
        {
            int randomNumber = random.Next(100); // Генерация случайного числа
            heap.Add(randomNumber); // Добавление случайного числа в кучу
            UpdateHeapListBox(); // Обновление отображения кучи
        }

        // Обработчик нажатия на кнопку "Удалить корень"
        private void RemoveRoot_Click(object sender, RoutedEventArgs e)
        {
            if (heap.Count > 0) // Проверка, что куча не пуста
            {
                heap.RemoveRoot(); // Удаление корня кучи
                UpdateHeapListBox(); // Обновление отображения кучи
            }
            else
            {
                MessageBox.Show("Куча пуста"); // Вывод сообщения, если куча пуста
            }
        }
    }
}
